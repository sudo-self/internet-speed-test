<?php

$serverLoc = '38.8339,-104.8214';
